# Presentació — 30/04/2026

- No assistència a classe per malaltia.
- No assistència a classe per malaltia.
- Entrega d'exàmens corregits.
- Comentari general dels resultats de la prova.
- Inici del bloc 1 de RA2.
- Presentació del nou bloc i explicació general del que es treballarà.

## RA
- RA2
