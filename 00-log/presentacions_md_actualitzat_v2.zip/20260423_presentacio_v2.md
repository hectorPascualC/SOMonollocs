# Presentació — 23/04/2026

- Examen teòric RA1.
- Recordatori inicial del funcionament de la prova i de com s'ha de respondre.
- Repàs previ de les transformacions de base a decimal i de decimal a altres bases.
- Resolució ràpida d'últims dubtes abans de començar.
- Examen pràctic.
- Aplicació dels continguts treballats a exercicis pràctics del RA1.

## RA
- RA1
